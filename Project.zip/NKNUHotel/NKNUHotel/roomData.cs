﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NKNUHotel
{
    class roomData
    {
        public string roomName;
        public string dateA;
        public string dateB;
        public string CName;
        //public string dateA;
        public string phone;
        public string BaTRu;
    }
}
