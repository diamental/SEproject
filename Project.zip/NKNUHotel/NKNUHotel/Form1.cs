﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace NKNUHotel
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string AllDataDirName = @"D:\NKNUHotel\";//全部的日檔 下面有個房間名的資料夾
        List<roomData> nowButton;
        bool[] EmptyRoom = new bool[30];

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
            DateTime 查詢日期 = monthCalendar1.SelectionStart;
            label3.Text = 查詢日期.ToString("yyyy/MM/dd dddd");
            textBox4.Text= 查詢日期.ToString("yyyyMMdd");
            //findEmptyRoom(查詢日期, 查詢日期);
        }

        private void button35_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                AllDataDirName = folderBrowserDialog1.SelectedPath;
                textBox9.Text = AllDataDirName;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            AllDataDirName=System.Environment.CurrentDirectory;
            folderBrowserDialog1.SelectedPath = AllDataDirName;            
            textBox9.Text = AllDataDirName;
            //monthCalendar1.SetDate
        }

        //private bool CheckEmptyRoomCSV(string 房間,string 起始日期, string 結束日期)
        private bool CheckEmptyRoomCSV(string 房間, string 日期)
        {
            string roomdateFILE = Path.Combine(Path.Combine(AllDataDirName, 房間), 日期+".csv");
            if (File.Exists(roomdateFILE))//房間檔案存在
            {
                return true;
            }
            else {
                return false;
            }
            //folderBrowserDialog1.SelectedPath = AllDataDirName;
            //textBox9.Text = AllDataDirName;
        }

        private DateTime addDay(DateTime dd)
        {
            dd=dd.AddDays(2);
            MessageBox.Show("安安"+dd.ToString());
            return dd;
        }

        private void findEmptyRoom(DateTime 起始日期, DateTime 結束日期)
        {
            for (int i = 1; i <= 3; i++)
            {
                for (int j = 1; j <= 10; j++)
                {


                    //for (DateTime date = 起始日期; DateTime.Compare(date, 結束日期) <= 0; addDay(date))
                    for (DateTime date = 起始日期; DateTime.Compare(date, 結束日期) <= 0; date=date.AddDays(1))
                    {
                        //ij房號 
                        //MessageBox.Show("i "+i+"j "+j+" "+date.ToString()+ DateTime.Compare(date, 結束日期).ToString());
                        CheckEmptyRoomCSV(i.ToString() + j.ToString("00"), date.ToString("yyyyMMdd"));


                    }

                }
            }


        }


        private void button36_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(AllDataDirName);
        }

        private void button33_Click(object sender, EventArgs e)
        {
            label10.Visible = true;
            label10.Text = "查詢中...";
            if (monthCalendar1.SelectionStart > monthCalendar2.SelectionStart)
                MessageBox.Show("查詢日期範圍相反");
            else
            {
                DateTime d1 = monthCalendar1.SelectionStart;
                DateTime d2 = monthCalendar2.SelectionStart;
                findEmptyRoom(d1, d2);
                //findEmptyRoom(monthCalendar1.SelectionStart, monthCalendar2.SelectionStart);
                label10.Text = "查詢完成";
            }
            
        }

        private void monthCalendar2_DateChanged(object sender, DateRangeEventArgs e)
        {
            textBox5.Text = monthCalendar2.SelectionStart.ToString("yyyyMMdd");
            button33.Enabled = true;
        }

        private void label11_Click(object sender, EventArgs e)
        {
            Form ab = new AboutBox1();
            ab.Show();
        }
    }
}
