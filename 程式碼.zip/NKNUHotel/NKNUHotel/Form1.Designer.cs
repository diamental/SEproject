﻿namespace NKNUHotel
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.buttonS = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.button34 = new System.Windows.Forms.Button();
            this.monthCalendar2 = new System.Windows.Forms.MonthCalendar();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.button33 = new System.Windows.Forms.Button();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.button32 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonRoom30 = new System.Windows.Forms.Button();
            this.buttonRoom29 = new System.Windows.Forms.Button();
            this.buttonRoom28 = new System.Windows.Forms.Button();
            this.buttonRoom27 = new System.Windows.Forms.Button();
            this.buttonRoom26 = new System.Windows.Forms.Button();
            this.buttonRoom25 = new System.Windows.Forms.Button();
            this.buttonRoom24 = new System.Windows.Forms.Button();
            this.buttonRoom23 = new System.Windows.Forms.Button();
            this.buttonRoom22 = new System.Windows.Forms.Button();
            this.buttonRoom21 = new System.Windows.Forms.Button();
            this.buttonRoom20 = new System.Windows.Forms.Button();
            this.buttonRoom19 = new System.Windows.Forms.Button();
            this.buttonRoom18 = new System.Windows.Forms.Button();
            this.buttonRoom17 = new System.Windows.Forms.Button();
            this.buttonRoom16 = new System.Windows.Forms.Button();
            this.buttonRoom15 = new System.Windows.Forms.Button();
            this.buttonRoom14 = new System.Windows.Forms.Button();
            this.buttonRoom13 = new System.Windows.Forms.Button();
            this.buttonRoom12 = new System.Windows.Forms.Button();
            this.buttonRoom11 = new System.Windows.Forms.Button();
            this.buttonRoom10 = new System.Windows.Forms.Button();
            this.buttonRoom9 = new System.Windows.Forms.Button();
            this.buttonRoom8 = new System.Windows.Forms.Button();
            this.buttonRoom7 = new System.Windows.Forms.Button();
            this.buttonRoom6 = new System.Windows.Forms.Button();
            this.buttonRoom5 = new System.Windows.Forms.Button();
            this.buttonRoom4 = new System.Windows.Forms.Button();
            this.buttonRoom3 = new System.Windows.Forms.Button();
            this.buttonRoom2 = new System.Windows.Forms.Button();
            this.buttonRoom1 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.button36 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(217, 18);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(140, 56);
            this.button1.TabIndex = 0;
            this.button1.Text = "登入";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(56, 18);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(155, 25);
            this.textBox1.TabIndex = 1;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(56, 49);
            this.textBox2.Name = "textBox2";
            this.textBox2.PasswordChar = '*';
            this.textBox2.Size = new System.Drawing.Size(155, 25);
            this.textBox2.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "帳號";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "密碼";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button4);
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.buttonS);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.buttonRoom30);
            this.groupBox1.Controls.Add(this.buttonRoom29);
            this.groupBox1.Controls.Add(this.buttonRoom28);
            this.groupBox1.Controls.Add(this.buttonRoom27);
            this.groupBox1.Controls.Add(this.buttonRoom26);
            this.groupBox1.Controls.Add(this.buttonRoom25);
            this.groupBox1.Controls.Add(this.buttonRoom24);
            this.groupBox1.Controls.Add(this.buttonRoom23);
            this.groupBox1.Controls.Add(this.buttonRoom22);
            this.groupBox1.Controls.Add(this.buttonRoom21);
            this.groupBox1.Controls.Add(this.buttonRoom20);
            this.groupBox1.Controls.Add(this.buttonRoom19);
            this.groupBox1.Controls.Add(this.buttonRoom18);
            this.groupBox1.Controls.Add(this.buttonRoom17);
            this.groupBox1.Controls.Add(this.buttonRoom16);
            this.groupBox1.Controls.Add(this.buttonRoom15);
            this.groupBox1.Controls.Add(this.buttonRoom14);
            this.groupBox1.Controls.Add(this.buttonRoom13);
            this.groupBox1.Controls.Add(this.buttonRoom12);
            this.groupBox1.Controls.Add(this.buttonRoom11);
            this.groupBox1.Controls.Add(this.buttonRoom10);
            this.groupBox1.Controls.Add(this.buttonRoom9);
            this.groupBox1.Controls.Add(this.buttonRoom8);
            this.groupBox1.Controls.Add(this.buttonRoom7);
            this.groupBox1.Controls.Add(this.buttonRoom6);
            this.groupBox1.Controls.Add(this.buttonRoom5);
            this.groupBox1.Controls.Add(this.buttonRoom4);
            this.groupBox1.Controls.Add(this.buttonRoom3);
            this.groupBox1.Controls.Add(this.buttonRoom2);
            this.groupBox1.Controls.Add(this.buttonRoom1);
            this.groupBox1.Location = new System.Drawing.Point(11, 96);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1296, 740);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "房間";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(21, 432);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(110, 62);
            this.button4.TabIndex = 37;
            this.button4.Text = "<";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(528, 432);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(110, 62);
            this.button3.TabIndex = 36;
            this.button3.Text = ">";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // buttonS
            // 
            this.buttonS.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonS.Location = new System.Drawing.Point(21, 24);
            this.buttonS.Name = "buttonS";
            this.buttonS.Size = new System.Drawing.Size(81, 46);
            this.buttonS.TabIndex = 35;
            this.buttonS.Text = "S";
            this.buttonS.UseVisualStyleBackColor = true;
            this.buttonS.Visible = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.checkBox1);
            this.groupBox2.Controls.Add(this.button34);
            this.groupBox2.Controls.Add(this.monthCalendar2);
            this.groupBox2.Controls.Add(this.textBox8);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.monthCalendar1);
            this.groupBox2.Controls.Add(this.textBox7);
            this.groupBox2.Controls.Add(this.button33);
            this.groupBox2.Controls.Add(this.textBox6);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.textBox5);
            this.groupBox2.Controls.Add(this.textBox4);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.textBox3);
            this.groupBox2.Controls.Add(this.button32);
            this.groupBox2.Location = new System.Drawing.Point(685, 30);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(593, 704);
            this.groupBox2.TabIndex = 34;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "訂房";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(395, 297);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(148, 56);
            this.button2.TabIndex = 46;
            this.button2.Text = "更改日期";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(295, 318);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 15);
            this.label10.TabIndex = 45;
            this.label10.Text = "label10";
            this.label10.Visible = false;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(227, 381);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(89, 19);
            this.checkBox1.TabIndex = 44;
            this.checkBox1.Text = "是否吸菸";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(298, 627);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(245, 51);
            this.button34.TabIndex = 43;
            this.button34.Text = "退訂";
            this.button34.UseVisualStyleBackColor = true;
            this.button34.Click += new System.EventHandler(this.button34_Click);
            // 
            // monthCalendar2
            // 
            this.monthCalendar2.Location = new System.Drawing.Point(298, 30);
            this.monthCalendar2.MaxSelectionCount = 1;
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.TabIndex = 42;
            this.monthCalendar2.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar2_DateChanged);
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(94, 473);
            this.textBox8.Multiline = true;
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(339, 120);
            this.textBox8.TabIndex = 41;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(23, 473);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 15);
            this.label8.TabIndex = 40;
            this.label8.Text = "備註";
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(12, 30);
            this.monthCalendar1.MaxSelectionCount = 1;
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 32;
            this.monthCalendar1.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar1_DateChanged);
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(298, 423);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(135, 25);
            this.textBox7.TabIndex = 39;
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(83, 293);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(148, 56);
            this.button33.TabIndex = 31;
            this.button33.Text = "查詢空房";
            this.button33.UseVisualStyleBackColor = true;
            this.button33.Click += new System.EventHandler(this.button33_Click);
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(97, 423);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(121, 25);
            this.textBox6.TabIndex = 38;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(224, 426);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 15);
            this.label7.TabIndex = 37;
            this.label7.Text = "連絡電話";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(23, 423);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 15);
            this.label6.TabIndex = 36;
            this.label6.Text = "訂房者";
            // 
            // textBox5
            // 
            this.textBox5.Enabled = false;
            this.textBox5.Location = new System.Drawing.Point(298, 250);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(135, 25);
            this.textBox5.TabIndex = 35;
            // 
            // textBox4
            // 
            this.textBox4.Enabled = false;
            this.textBox4.Location = new System.Drawing.Point(83, 250);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(135, 25);
            this.textBox4.TabIndex = 34;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 253);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 15);
            this.label5.TabIndex = 33;
            this.label5.Text = "過夜期間";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 381);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 15);
            this.label4.TabIndex = 32;
            this.label4.Text = "房間";
            // 
            // textBox3
            // 
            this.textBox3.Enabled = false;
            this.textBox3.Location = new System.Drawing.Point(97, 378);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 25);
            this.textBox3.TabIndex = 31;
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(29, 627);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(245, 51);
            this.button32.TabIndex = 30;
            this.button32.Text = "訂房";
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("新細明體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(40, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(124, 28);
            this.label3.TabIndex = 33;
            this.label3.Text = "查詢日期";
            // 
            // buttonRoom30
            // 
            this.buttonRoom30.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonRoom30.Location = new System.Drawing.Point(557, 348);
            this.buttonRoom30.Name = "buttonRoom30";
            this.buttonRoom30.Size = new System.Drawing.Size(81, 46);
            this.buttonRoom30.TabIndex = 29;
            this.buttonRoom30.Text = "310";
            this.buttonRoom30.UseVisualStyleBackColor = true;
            this.buttonRoom30.Click += new System.EventHandler(this.buttonRoom30_Click);
            // 
            // buttonRoom29
            // 
            this.buttonRoom29.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonRoom29.Location = new System.Drawing.Point(557, 283);
            this.buttonRoom29.Name = "buttonRoom29";
            this.buttonRoom29.Size = new System.Drawing.Size(81, 46);
            this.buttonRoom29.TabIndex = 28;
            this.buttonRoom29.Text = "309";
            this.buttonRoom29.UseVisualStyleBackColor = true;
            this.buttonRoom29.Click += new System.EventHandler(this.buttonRoom29_Click);
            // 
            // buttonRoom28
            // 
            this.buttonRoom28.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonRoom28.Location = new System.Drawing.Point(557, 219);
            this.buttonRoom28.Name = "buttonRoom28";
            this.buttonRoom28.Size = new System.Drawing.Size(81, 46);
            this.buttonRoom28.TabIndex = 27;
            this.buttonRoom28.Text = "308";
            this.buttonRoom28.UseVisualStyleBackColor = true;
            this.buttonRoom28.Click += new System.EventHandler(this.buttonRoom28_Click);
            // 
            // buttonRoom27
            // 
            this.buttonRoom27.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonRoom27.Location = new System.Drawing.Point(557, 154);
            this.buttonRoom27.Name = "buttonRoom27";
            this.buttonRoom27.Size = new System.Drawing.Size(81, 46);
            this.buttonRoom27.TabIndex = 26;
            this.buttonRoom27.Text = "307";
            this.buttonRoom27.UseVisualStyleBackColor = true;
            this.buttonRoom27.Click += new System.EventHandler(this.buttonRoom27_Click);
            // 
            // buttonRoom26
            // 
            this.buttonRoom26.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonRoom26.Location = new System.Drawing.Point(557, 91);
            this.buttonRoom26.Name = "buttonRoom26";
            this.buttonRoom26.Size = new System.Drawing.Size(81, 46);
            this.buttonRoom26.TabIndex = 25;
            this.buttonRoom26.Text = "306";
            this.buttonRoom26.UseVisualStyleBackColor = true;
            this.buttonRoom26.Click += new System.EventHandler(this.buttonRoom26_Click);
            // 
            // buttonRoom25
            // 
            this.buttonRoom25.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonRoom25.Location = new System.Drawing.Point(458, 348);
            this.buttonRoom25.Name = "buttonRoom25";
            this.buttonRoom25.Size = new System.Drawing.Size(81, 46);
            this.buttonRoom25.TabIndex = 24;
            this.buttonRoom25.Text = "305";
            this.buttonRoom25.UseVisualStyleBackColor = true;
            this.buttonRoom25.Click += new System.EventHandler(this.buttonRoom25_Click);
            // 
            // buttonRoom24
            // 
            this.buttonRoom24.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonRoom24.Location = new System.Drawing.Point(458, 283);
            this.buttonRoom24.Name = "buttonRoom24";
            this.buttonRoom24.Size = new System.Drawing.Size(81, 46);
            this.buttonRoom24.TabIndex = 23;
            this.buttonRoom24.Text = "304";
            this.buttonRoom24.UseVisualStyleBackColor = true;
            this.buttonRoom24.Click += new System.EventHandler(this.buttonRoom24_Click);
            // 
            // buttonRoom23
            // 
            this.buttonRoom23.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonRoom23.Location = new System.Drawing.Point(458, 218);
            this.buttonRoom23.Name = "buttonRoom23";
            this.buttonRoom23.Size = new System.Drawing.Size(81, 46);
            this.buttonRoom23.TabIndex = 22;
            this.buttonRoom23.Text = "303";
            this.buttonRoom23.UseVisualStyleBackColor = true;
            this.buttonRoom23.Click += new System.EventHandler(this.buttonRoom23_Click);
            // 
            // buttonRoom22
            // 
            this.buttonRoom22.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonRoom22.Location = new System.Drawing.Point(458, 155);
            this.buttonRoom22.Name = "buttonRoom22";
            this.buttonRoom22.Size = new System.Drawing.Size(81, 46);
            this.buttonRoom22.TabIndex = 21;
            this.buttonRoom22.Text = "302";
            this.buttonRoom22.UseVisualStyleBackColor = true;
            this.buttonRoom22.Click += new System.EventHandler(this.buttonRoom22_Click);
            // 
            // buttonRoom21
            // 
            this.buttonRoom21.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonRoom21.Location = new System.Drawing.Point(458, 91);
            this.buttonRoom21.Name = "buttonRoom21";
            this.buttonRoom21.Size = new System.Drawing.Size(81, 46);
            this.buttonRoom21.TabIndex = 20;
            this.buttonRoom21.Text = "301";
            this.buttonRoom21.UseVisualStyleBackColor = true;
            this.buttonRoom21.Click += new System.EventHandler(this.buttonRoom21_Click);
            // 
            // buttonRoom20
            // 
            this.buttonRoom20.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonRoom20.Location = new System.Drawing.Point(338, 348);
            this.buttonRoom20.Name = "buttonRoom20";
            this.buttonRoom20.Size = new System.Drawing.Size(81, 46);
            this.buttonRoom20.TabIndex = 19;
            this.buttonRoom20.Text = "210";
            this.buttonRoom20.UseVisualStyleBackColor = true;
            this.buttonRoom20.Click += new System.EventHandler(this.buttonRoom20_Click);
            // 
            // buttonRoom19
            // 
            this.buttonRoom19.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonRoom19.Location = new System.Drawing.Point(338, 283);
            this.buttonRoom19.Name = "buttonRoom19";
            this.buttonRoom19.Size = new System.Drawing.Size(81, 46);
            this.buttonRoom19.TabIndex = 18;
            this.buttonRoom19.Text = "209";
            this.buttonRoom19.UseVisualStyleBackColor = true;
            this.buttonRoom19.Click += new System.EventHandler(this.buttonRoom19_Click);
            // 
            // buttonRoom18
            // 
            this.buttonRoom18.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonRoom18.Location = new System.Drawing.Point(338, 219);
            this.buttonRoom18.Name = "buttonRoom18";
            this.buttonRoom18.Size = new System.Drawing.Size(81, 46);
            this.buttonRoom18.TabIndex = 17;
            this.buttonRoom18.Text = "208";
            this.buttonRoom18.UseVisualStyleBackColor = true;
            this.buttonRoom18.Click += new System.EventHandler(this.buttonRoom18_Click);
            // 
            // buttonRoom17
            // 
            this.buttonRoom17.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonRoom17.Location = new System.Drawing.Point(338, 154);
            this.buttonRoom17.Name = "buttonRoom17";
            this.buttonRoom17.Size = new System.Drawing.Size(81, 46);
            this.buttonRoom17.TabIndex = 16;
            this.buttonRoom17.Text = "207";
            this.buttonRoom17.UseVisualStyleBackColor = true;
            this.buttonRoom17.Click += new System.EventHandler(this.buttonRoom17_Click);
            // 
            // buttonRoom16
            // 
            this.buttonRoom16.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonRoom16.Location = new System.Drawing.Point(338, 91);
            this.buttonRoom16.Name = "buttonRoom16";
            this.buttonRoom16.Size = new System.Drawing.Size(81, 46);
            this.buttonRoom16.TabIndex = 15;
            this.buttonRoom16.Text = "206";
            this.buttonRoom16.UseVisualStyleBackColor = true;
            this.buttonRoom16.Click += new System.EventHandler(this.buttonRoom16_Click);
            // 
            // buttonRoom15
            // 
            this.buttonRoom15.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonRoom15.Location = new System.Drawing.Point(239, 348);
            this.buttonRoom15.Name = "buttonRoom15";
            this.buttonRoom15.Size = new System.Drawing.Size(81, 46);
            this.buttonRoom15.TabIndex = 14;
            this.buttonRoom15.Text = "205";
            this.buttonRoom15.UseVisualStyleBackColor = true;
            this.buttonRoom15.Click += new System.EventHandler(this.buttonRoom15_Click);
            // 
            // buttonRoom14
            // 
            this.buttonRoom14.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonRoom14.Location = new System.Drawing.Point(239, 283);
            this.buttonRoom14.Name = "buttonRoom14";
            this.buttonRoom14.Size = new System.Drawing.Size(81, 46);
            this.buttonRoom14.TabIndex = 13;
            this.buttonRoom14.Text = "204";
            this.buttonRoom14.UseVisualStyleBackColor = true;
            this.buttonRoom14.Click += new System.EventHandler(this.buttonRoom14_Click);
            // 
            // buttonRoom13
            // 
            this.buttonRoom13.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonRoom13.Location = new System.Drawing.Point(239, 218);
            this.buttonRoom13.Name = "buttonRoom13";
            this.buttonRoom13.Size = new System.Drawing.Size(81, 46);
            this.buttonRoom13.TabIndex = 12;
            this.buttonRoom13.Text = "203";
            this.buttonRoom13.UseVisualStyleBackColor = true;
            this.buttonRoom13.Click += new System.EventHandler(this.buttonRoom13_Click);
            // 
            // buttonRoom12
            // 
            this.buttonRoom12.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonRoom12.Location = new System.Drawing.Point(239, 155);
            this.buttonRoom12.Name = "buttonRoom12";
            this.buttonRoom12.Size = new System.Drawing.Size(81, 46);
            this.buttonRoom12.TabIndex = 11;
            this.buttonRoom12.Text = "202";
            this.buttonRoom12.UseVisualStyleBackColor = true;
            this.buttonRoom12.Click += new System.EventHandler(this.buttonRoom12_Click);
            // 
            // buttonRoom11
            // 
            this.buttonRoom11.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonRoom11.Location = new System.Drawing.Point(239, 91);
            this.buttonRoom11.Name = "buttonRoom11";
            this.buttonRoom11.Size = new System.Drawing.Size(81, 46);
            this.buttonRoom11.TabIndex = 10;
            this.buttonRoom11.Text = "201";
            this.buttonRoom11.UseVisualStyleBackColor = true;
            this.buttonRoom11.Click += new System.EventHandler(this.buttonRoom11_Click);
            // 
            // buttonRoom10
            // 
            this.buttonRoom10.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonRoom10.Location = new System.Drawing.Point(120, 348);
            this.buttonRoom10.Name = "buttonRoom10";
            this.buttonRoom10.Size = new System.Drawing.Size(81, 46);
            this.buttonRoom10.TabIndex = 9;
            this.buttonRoom10.Text = "110";
            this.buttonRoom10.UseVisualStyleBackColor = true;
            this.buttonRoom10.Click += new System.EventHandler(this.buttonRoom10_Click);
            // 
            // buttonRoom9
            // 
            this.buttonRoom9.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonRoom9.Location = new System.Drawing.Point(120, 283);
            this.buttonRoom9.Name = "buttonRoom9";
            this.buttonRoom9.Size = new System.Drawing.Size(81, 46);
            this.buttonRoom9.TabIndex = 8;
            this.buttonRoom9.Text = "109";
            this.buttonRoom9.UseVisualStyleBackColor = true;
            this.buttonRoom9.Click += new System.EventHandler(this.buttonRoom9_Click);
            // 
            // buttonRoom8
            // 
            this.buttonRoom8.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonRoom8.Location = new System.Drawing.Point(120, 219);
            this.buttonRoom8.Name = "buttonRoom8";
            this.buttonRoom8.Size = new System.Drawing.Size(81, 46);
            this.buttonRoom8.TabIndex = 7;
            this.buttonRoom8.Text = "108";
            this.buttonRoom8.UseVisualStyleBackColor = true;
            this.buttonRoom8.Click += new System.EventHandler(this.buttonRoom8_Click);
            // 
            // buttonRoom7
            // 
            this.buttonRoom7.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonRoom7.Location = new System.Drawing.Point(120, 154);
            this.buttonRoom7.Name = "buttonRoom7";
            this.buttonRoom7.Size = new System.Drawing.Size(81, 46);
            this.buttonRoom7.TabIndex = 6;
            this.buttonRoom7.Text = "107";
            this.buttonRoom7.UseVisualStyleBackColor = true;
            this.buttonRoom7.Click += new System.EventHandler(this.buttonRoom7_Click);
            // 
            // buttonRoom6
            // 
            this.buttonRoom6.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonRoom6.Location = new System.Drawing.Point(120, 91);
            this.buttonRoom6.Name = "buttonRoom6";
            this.buttonRoom6.Size = new System.Drawing.Size(81, 46);
            this.buttonRoom6.TabIndex = 5;
            this.buttonRoom6.Text = "106";
            this.buttonRoom6.UseVisualStyleBackColor = true;
            this.buttonRoom6.Click += new System.EventHandler(this.buttonRoom6_Click);
            // 
            // buttonRoom5
            // 
            this.buttonRoom5.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonRoom5.Location = new System.Drawing.Point(21, 348);
            this.buttonRoom5.Name = "buttonRoom5";
            this.buttonRoom5.Size = new System.Drawing.Size(81, 46);
            this.buttonRoom5.TabIndex = 4;
            this.buttonRoom5.Text = "105";
            this.buttonRoom5.UseVisualStyleBackColor = true;
            this.buttonRoom5.Click += new System.EventHandler(this.buttonRoom5_Click);
            // 
            // buttonRoom4
            // 
            this.buttonRoom4.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonRoom4.Location = new System.Drawing.Point(21, 283);
            this.buttonRoom4.Name = "buttonRoom4";
            this.buttonRoom4.Size = new System.Drawing.Size(81, 46);
            this.buttonRoom4.TabIndex = 3;
            this.buttonRoom4.Text = "104";
            this.buttonRoom4.UseVisualStyleBackColor = true;
            this.buttonRoom4.Click += new System.EventHandler(this.buttonRoom4_Click);
            // 
            // buttonRoom3
            // 
            this.buttonRoom3.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonRoom3.Location = new System.Drawing.Point(21, 218);
            this.buttonRoom3.Name = "buttonRoom3";
            this.buttonRoom3.Size = new System.Drawing.Size(81, 46);
            this.buttonRoom3.TabIndex = 2;
            this.buttonRoom3.Text = "103";
            this.buttonRoom3.UseVisualStyleBackColor = true;
            this.buttonRoom3.Click += new System.EventHandler(this.buttonRoom3_Click);
            // 
            // buttonRoom2
            // 
            this.buttonRoom2.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonRoom2.Location = new System.Drawing.Point(21, 155);
            this.buttonRoom2.Name = "buttonRoom2";
            this.buttonRoom2.Size = new System.Drawing.Size(81, 46);
            this.buttonRoom2.TabIndex = 1;
            this.buttonRoom2.Text = "102";
            this.buttonRoom2.UseVisualStyleBackColor = true;
            this.buttonRoom2.Click += new System.EventHandler(this.buttonRoom2_Click);
            // 
            // buttonRoom1
            // 
            this.buttonRoom1.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.buttonRoom1.Location = new System.Drawing.Point(21, 91);
            this.buttonRoom1.Name = "buttonRoom1";
            this.buttonRoom1.Size = new System.Drawing.Size(81, 46);
            this.buttonRoom1.TabIndex = 0;
            this.buttonRoom1.Text = "101";
            this.buttonRoom1.UseVisualStyleBackColor = true;
            this.buttonRoom1.Click += new System.EventHandler(this.buttonRoom1_Click);
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(779, 13);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(128, 30);
            this.button35.TabIndex = 6;
            this.button35.Text = "設定日檔目錄";
            this.button35.UseVisualStyleBackColor = true;
            this.button35.Click += new System.EventHandler(this.button35_Click);
            // 
            // textBox9
            // 
            this.textBox9.Enabled = false;
            this.textBox9.Location = new System.Drawing.Point(928, 14);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(377, 25);
            this.textBox9.TabIndex = 7;
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(779, 52);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(128, 29);
            this.button36.TabIndex = 8;
            this.button36.Text = "開啟目錄";
            this.button36.UseVisualStyleBackColor = true;
            this.button36.Click += new System.EventHandler(this.button36_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("新細明體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label9.Location = new System.Drawing.Point(374, 29);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(170, 28);
            this.label9.TabIndex = 35;
            this.label9.Text = "NKNU H歡迎";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label11.Location = new System.Drawing.Point(1273, 66);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(32, 15);
            this.label11.TabIndex = 36;
            this.label11.Text = "0.10";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1319, 848);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.button36);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.button35);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "NKNU旅店";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonRoom20;
        private System.Windows.Forms.Button buttonRoom19;
        private System.Windows.Forms.Button buttonRoom18;
        private System.Windows.Forms.Button buttonRoom17;
        private System.Windows.Forms.Button buttonRoom16;
        private System.Windows.Forms.Button buttonRoom15;
        private System.Windows.Forms.Button buttonRoom14;
        private System.Windows.Forms.Button buttonRoom13;
        private System.Windows.Forms.Button buttonRoom12;
        private System.Windows.Forms.Button buttonRoom11;
        private System.Windows.Forms.Button buttonRoom10;
        private System.Windows.Forms.Button buttonRoom9;
        private System.Windows.Forms.Button buttonRoom8;
        private System.Windows.Forms.Button buttonRoom7;
        private System.Windows.Forms.Button buttonRoom6;
        private System.Windows.Forms.Button buttonRoom5;
        private System.Windows.Forms.Button buttonRoom4;
        private System.Windows.Forms.Button buttonRoom3;
        private System.Windows.Forms.Button buttonRoom2;
        private System.Windows.Forms.Button buttonRoom1;
        private System.Windows.Forms.Button buttonRoom30;
        private System.Windows.Forms.Button buttonRoom29;
        private System.Windows.Forms.Button buttonRoom28;
        private System.Windows.Forms.Button buttonRoom27;
        private System.Windows.Forms.Button buttonRoom26;
        private System.Windows.Forms.Button buttonRoom25;
        private System.Windows.Forms.Button buttonRoom24;
        private System.Windows.Forms.Button buttonRoom23;
        private System.Windows.Forms.Button buttonRoom22;
        private System.Windows.Forms.Button buttonRoom21;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.MonthCalendar monthCalendar2;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button buttonS;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
    }
}

