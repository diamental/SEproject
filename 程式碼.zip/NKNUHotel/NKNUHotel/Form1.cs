﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace NKNUHotel
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string AllDataDirName = @"D:\NKNUHotel\";//全部的日檔 下面有個房間名的資料夾
        List<roomData> nowButton;
        bool[] EmptyRoom = new bool[30];//TRUE 是空房

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
            DateTime 查詢日期 = monthCalendar1.SelectionStart;
            //label3.Text = 查詢日期.ToString("yyyy/MM/dd dddd");
            textBox4.Text= 查詢日期.ToString("yyyy/MM/dd");
            //findEmptyRoom(查詢日期, 查詢日期);
            findEmptyRoom(查詢日期);
        }

        private void monthCalendar2_DateChanged(object sender, DateRangeEventArgs e)
        {
            textBox5.Text = monthCalendar2.SelectionStart.ToString("yyyy/MM/dd");
            button33.Enabled = true;
        }

        private void button35_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                AllDataDirName = folderBrowserDialog1.SelectedPath;
                textBox9.Text = AllDataDirName;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            AllDataDirName=Path.Combine( System.Environment.CurrentDirectory, "NKNUHotel\\");
            if (!Directory.Exists(AllDataDirName))
                Directory.CreateDirectory(AllDataDirName);
            folderBrowserDialog1.SelectedPath = AllDataDirName;            
            textBox9.Text = AllDataDirName;
            //monthCalendar1.SetDate
            groupBox1.Enabled = false;
        }

        //private bool CheckEmptyRoomCSV(string 房間,string 起始日期, string 結束日期)
        private bool CheckEmptyRoomCSV(string 房間, string 日期)
        {
            string roomdateFILE = Path.Combine(Path.Combine(AllDataDirName, 房間), 房間+日期 +".csv");
            if (!File.Exists(roomdateFILE))//房間檔案存在
            {
                return true;
            }
            else {
                return false;
            }
            //folderBrowserDialog1.SelectedPath = AllDataDirName;
            //textBox9.Text = AllDataDirName;
        }

        //private DateTime addDay(DateTime dd)
        //{
        //    dd=dd.AddDays(2);
        //    MessageBox.Show("安安"+dd.ToString());
        //    return dd;
        //}

        private void findEmptyRoom(DateTime 單一日期)
        {
            label3.Text = 單一日期.ToString("yyyy/MM/dd dddd");
            for (int i = 1; i <= 3; i++)
            {
                for (int j = 1; j <= 10; j++)
                {
                    //for (DateTime date = 起始日期; DateTime.Compare(date, 結束日期) <= 0; addDay(date))
                    for (DateTime date = 單一日期; DateTime.Compare(date, 單一日期) <= 0; date=date.AddDays(1))
                    {
                        //ij房號 
                        //MessageBox.Show("i "+i+"j "+j+" "+date.ToString()+ DateTime.Compare(date, 結束日期).ToString());

                        //MessageBox.Show(i.ToString() + j.ToString("00"), date.ToString("yyyyMMdd"));
                        EmptyRoom[(i-1)*10+j-1] = CheckEmptyRoomCSV(i.ToString() + j.ToString("00"), date.ToString("yyyyMMdd"));
                    }

                }
            }
            ShowEmptyRoom();
        }

        private void findEmptyRoom(DateTime 起始日期, DateTime 結束日期)
        {

            for (int i = 1; i <= 3; i++)
            {
                for (int j = 1; j <= 10; j++)
                {
                    //for (DateTime date = 起始日期; DateTime.Compare(date, 結束日期) <= 0; addDay(date))
                    for (DateTime date = 起始日期; DateTime.Compare(date, 結束日期) <= 0; date = date.AddDays(1))
                    {
                        //ij房號 
                        //MessageBox.Show("i "+i+"j "+j+" "+date.ToString()+ DateTime.Compare(date, 結束日期).ToString());

                        //MessageBox.Show(i.ToString() + j.ToString("00"), date.ToString("yyyyMMdd"));
                        EmptyRoom[(i - 1) * 10 + j - 1] = CheckEmptyRoomCSV(i.ToString() + j.ToString("00"), date.ToString("yyyyMMdd"));

                    }

                }
            }
            ShowEmptyRoomSS();

        }
        private void ShowEmptyRoomSS()
        {
            changeButtonInformationSS(ref buttonRoom1, EmptyRoom[0]);
            changeButtonInformationSS(ref buttonRoom2, EmptyRoom[1]);
            changeButtonInformationSS(ref buttonRoom3, EmptyRoom[2]);
            changeButtonInformationSS(ref buttonRoom4, EmptyRoom[3]);
            changeButtonInformationSS(ref buttonRoom5, EmptyRoom[4]);
            changeButtonInformationSS(ref buttonRoom6, EmptyRoom[5]);
            changeButtonInformationSS(ref buttonRoom7, EmptyRoom[6]);
            changeButtonInformationSS(ref buttonRoom8, EmptyRoom[7]);
            changeButtonInformationSS(ref buttonRoom9, EmptyRoom[8]);
            changeButtonInformationSS(ref buttonRoom10, EmptyRoom[9]);
            changeButtonInformationSS(ref buttonRoom11, EmptyRoom[10]);
            changeButtonInformationSS(ref buttonRoom12, EmptyRoom[11]);
            changeButtonInformationSS(ref buttonRoom13, EmptyRoom[12]);
            changeButtonInformationSS(ref buttonRoom14, EmptyRoom[13]);
            changeButtonInformationSS(ref buttonRoom15, EmptyRoom[14]);
            changeButtonInformationSS(ref buttonRoom16, EmptyRoom[15]);
            changeButtonInformationSS(ref buttonRoom17, EmptyRoom[16]);
            changeButtonInformationSS(ref buttonRoom18, EmptyRoom[17]);
            changeButtonInformationSS(ref buttonRoom19, EmptyRoom[18]);
            changeButtonInformationSS(ref buttonRoom20, EmptyRoom[19]);
            changeButtonInformationSS(ref buttonRoom21, EmptyRoom[20]);
            changeButtonInformationSS(ref buttonRoom22, EmptyRoom[21]);
            changeButtonInformationSS(ref buttonRoom23, EmptyRoom[22]);
            changeButtonInformationSS(ref buttonRoom24, EmptyRoom[23]);
            changeButtonInformationSS(ref buttonRoom25, EmptyRoom[24]);
            changeButtonInformationSS(ref buttonRoom26, EmptyRoom[25]);
            changeButtonInformationSS(ref buttonRoom27, EmptyRoom[26]);
            changeButtonInformationSS(ref buttonRoom28, EmptyRoom[27]);
            changeButtonInformationSS(ref buttonRoom29, EmptyRoom[28]);
            changeButtonInformationSS(ref buttonRoom30, EmptyRoom[29]);
            this.Update();
        }

        private void changeButtonInformationSS(ref Button bu, bool isEmpty)
        {
            if (isEmpty)
            {
                bu.BackColor = Color.PaleGreen;
                bu.Enabled = true;
            }                
            else
            {
                bu.BackColor = buttonS.BackColor;
                bu.Enabled = false;
            }
        }


        private void ShowEmptyRoom()
        {
            changeButtonInformation(ref buttonRoom1, EmptyRoom[0]);
            changeButtonInformation(ref buttonRoom2, EmptyRoom[1]);
            changeButtonInformation(ref buttonRoom3, EmptyRoom[2]);
            changeButtonInformation(ref buttonRoom4, EmptyRoom[3]);
            changeButtonInformation(ref buttonRoom5, EmptyRoom[4]);
            changeButtonInformation(ref buttonRoom6, EmptyRoom[5]);
            changeButtonInformation(ref buttonRoom7, EmptyRoom[6]);
            changeButtonInformation(ref buttonRoom8, EmptyRoom[7]);
            changeButtonInformation(ref buttonRoom9, EmptyRoom[8]);
            changeButtonInformation(ref buttonRoom10, EmptyRoom[9]);
            changeButtonInformation(ref buttonRoom11, EmptyRoom[10]);
            changeButtonInformation(ref buttonRoom12, EmptyRoom[11]);
            changeButtonInformation(ref buttonRoom13, EmptyRoom[12]);
            changeButtonInformation(ref buttonRoom14, EmptyRoom[13]);
            changeButtonInformation(ref buttonRoom15, EmptyRoom[14]);
            changeButtonInformation(ref buttonRoom16, EmptyRoom[15]);
            changeButtonInformation(ref buttonRoom17, EmptyRoom[16]);
            changeButtonInformation(ref buttonRoom18, EmptyRoom[17]);
            changeButtonInformation(ref buttonRoom19, EmptyRoom[18]);
            changeButtonInformation(ref buttonRoom20, EmptyRoom[19]);
            changeButtonInformation(ref buttonRoom21, EmptyRoom[20]);
            changeButtonInformation(ref buttonRoom22, EmptyRoom[21]);
            changeButtonInformation(ref buttonRoom23, EmptyRoom[22]);
            changeButtonInformation(ref buttonRoom24, EmptyRoom[23]);
            changeButtonInformation(ref buttonRoom25, EmptyRoom[24]);
            changeButtonInformation(ref buttonRoom26, EmptyRoom[25]);
            changeButtonInformation(ref buttonRoom27, EmptyRoom[26]);
            changeButtonInformation(ref buttonRoom28, EmptyRoom[27]);
            changeButtonInformation(ref buttonRoom29, EmptyRoom[28]);
            changeButtonInformation(ref buttonRoom30, EmptyRoom[29]);
            this.Update();
        }

        private void changeButtonInformation(ref Button bu,bool isEmpty)
        {
            if (isEmpty)
                bu.BackColor = Color.PaleGreen;
            else
                bu.BackColor = Color.Pink;
            //bu.BackColor = buttonS.BackColor;
        }


        private void button36_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(AllDataDirName);
        }

        private void button33_Click(object sender, EventArgs e)
        {
            label10.Visible = true;
            label10.Text = "查詢中...";
            if (monthCalendar1.SelectionStart > monthCalendar2.SelectionStart)
            {
                MessageBox.Show("查詢日期範圍相反");
                label10.Visible = false;
            }
                
            else
            {
                monthCalendar1.Enabled = false;
                monthCalendar2.Enabled = false;

                DateTime d1 = monthCalendar1.SelectionStart;
                DateTime d2 = monthCalendar2.SelectionStart;
                findEmptyRoom(d1, d2);
                //findEmptyRoom(monthCalendar1.SelectionStart, monthCalendar2.SelectionStart);
                label10.Text = "查詢完成";
                label3.Text = d1.ToString("yyyy/MM/dd dddd") +" ~ " +d2.ToString("yyyy/MM/dd dddd");
            }
            
        }

        

        private void label11_Click(object sender, EventArgs e)
        {
            Form ab = new AboutBox1();
            ab.Show();
        }

        private void showRoomData(string 房間,DateTime 日期)
        {
            string line;
            int counter = 0;

            //string roomdateFILE = Path.Combine(Path.Combine(AllDataDirName, 房間), 日期 + ".csv");
            string roomDirName = Path.Combine(AllDataDirName, 房間 + "\\");
            string roomdateFILE = Path.Combine(roomDirName, 房間+ 日期.ToString("yyyyMMdd") + ".csv");


            System.IO.StreamReader file = new System.IO.StreamReader(roomdateFILE);
            while ((line = file.ReadLine()) != null)
            {
                switch(counter)
                {
                    case 0:
                        //入住日期
                        textBox4.Text = line;
                        break;
                    case 1:
                        //離開日期
                        textBox5.Text = line;
                        break;
                    case 2:
                        //房號
                        textBox3.Text = line;
                        break;                    
                    case 3:
                        //抽菸
                        if (line == "抽菸")
                            checkBox1.Checked = true;
                        else
                            checkBox1.Checked = false;
                        break;
                    case 4:
                        //客人名字
                        textBox6.Text = line;
                        break;
                    case 5:
                        //電話
                        textBox7.Text = line;
                        break;
                    case 6:
                        //備註
                        textBox8.Text = line;
                        break;
                    default:
                        textBox8.Text += Environment.NewLine + line;
                        break;
                }
                counter++;
            }

            file.Close();
        }

        private void buttonRoom1_Click(object sender, EventArgs e)
        {
            if (EmptyRoom[0])//如果是空房
            {
                textBox3.Text = buttonRoom1.Text;
            } 
            else
            {
                showRoomData(buttonRoom1.Text,monthCalendar1.SelectionStart);
            }
        }

        private void buttonRoom2_Click(object sender, EventArgs e)
        {
            if (EmptyRoom[1])//如果是空房
            {
                textBox3.Text = buttonRoom2.Text;
            }
            else
            {
                showRoomData(buttonRoom2.Text, monthCalendar1.SelectionStart);
            }
        }

        private void buttonRoom3_Click(object sender, EventArgs e)
        {
            if (EmptyRoom[2])//如果是空房
            {
                textBox3.Text = buttonRoom3.Text;
            }
            else
            {
                showRoomData(buttonRoom3.Text, monthCalendar1.SelectionStart);
            }
        }

        private void buttonRoom4_Click(object sender, EventArgs e)
        {
            if (EmptyRoom[3])//如果是空房
            {
                textBox3.Text = buttonRoom4.Text;
            }
            else
            {
                showRoomData(buttonRoom4.Text, monthCalendar1.SelectionStart);
            }
        }

        private void buttonRoom5_Click(object sender, EventArgs e)
        {
            if (EmptyRoom[4])//如果是空房
            {
                textBox3.Text = buttonRoom5.Text;
            }
            else
            {
                showRoomData(buttonRoom5.Text, monthCalendar1.SelectionStart);
            }
        }

        private void buttonRoom6_Click(object sender, EventArgs e)
        {
            if (EmptyRoom[5])//如果是空房
            {
                textBox3.Text = buttonRoom6.Text;
            }
            else
            {
                showRoomData(buttonRoom6.Text, monthCalendar1.SelectionStart);
            }
        }

        private void buttonRoom7_Click(object sender, EventArgs e)
        {
            if (EmptyRoom[6])//如果是空房
            {
                textBox3.Text = buttonRoom7.Text;
            }
            else
            {
                showRoomData(buttonRoom7.Text, monthCalendar1.SelectionStart);
            }
        }

        private void buttonRoom8_Click(object sender, EventArgs e)
        {
            if (EmptyRoom[7])//如果是空房
            {
                textBox3.Text = buttonRoom8.Text;
            }
            else
            {
                showRoomData(buttonRoom8.Text, monthCalendar1.SelectionStart);
            }
        }

        private void buttonRoom9_Click(object sender, EventArgs e)
        {
            if (EmptyRoom[8])//如果是空房
            {
                textBox3.Text = buttonRoom9.Text;
            }
            else
            {
                showRoomData(buttonRoom9.Text, monthCalendar1.SelectionStart);
            }
        }

        private void buttonRoom10_Click(object sender, EventArgs e)
        {
            if (EmptyRoom[9])//如果是空房
            {
                textBox3.Text = buttonRoom10.Text;
            }
            else
            {
                showRoomData(buttonRoom10.Text, monthCalendar1.SelectionStart);
            }
        }

        private void buttonRoom11_Click(object sender, EventArgs e)
        {
            if (EmptyRoom[10])//如果是空房
            {
                textBox3.Text = buttonRoom11.Text;
            }
            else
            {
                showRoomData(buttonRoom11.Text, monthCalendar1.SelectionStart);
            }
        }

        private void buttonRoom12_Click(object sender, EventArgs e)
        {
            if (EmptyRoom[11])//如果是空房
            {
                textBox3.Text = buttonRoom12.Text;
            }
            else
            {
                showRoomData(buttonRoom12.Text, monthCalendar1.SelectionStart);
            }
        }

        private void buttonRoom13_Click(object sender, EventArgs e)
        {
            if (EmptyRoom[12])//如果是空房
            {
                textBox3.Text = buttonRoom13.Text;
            }
            else
            {
                showRoomData(buttonRoom13.Text, monthCalendar1.SelectionStart);
            }
        }

        private void buttonRoom14_Click(object sender, EventArgs e)
        {
            if (EmptyRoom[13])//如果是空房
            {
                textBox3.Text = buttonRoom14.Text;
            }
            else
            {
                showRoomData(buttonRoom14.Text, monthCalendar1.SelectionStart);
            }
        }

        private void buttonRoom15_Click(object sender, EventArgs e)
        {
            if (EmptyRoom[14])//如果是空房
            {
                textBox3.Text = buttonRoom15.Text;
            }
            else
            {
                showRoomData(buttonRoom15.Text, monthCalendar1.SelectionStart);
            }
        }

        private void buttonRoom16_Click(object sender, EventArgs e)
        {
            if (EmptyRoom[15])//如果是空房
            {
                textBox3.Text = buttonRoom16.Text;
            }
            else
            {
                showRoomData(buttonRoom16.Text, monthCalendar1.SelectionStart);
            }
        }

        private void buttonRoom17_Click(object sender, EventArgs e)
        {
            if (EmptyRoom[16])//如果是空房
            {
                textBox3.Text = buttonRoom17.Text;
            }
            else
            {
                showRoomData(buttonRoom17.Text, monthCalendar1.SelectionStart);
            }
        }

        private void buttonRoom18_Click(object sender, EventArgs e)
        {
            if (EmptyRoom[17])//如果是空房
            {
                textBox3.Text = buttonRoom18.Text;
            }
            else
            {
                showRoomData(buttonRoom18.Text, monthCalendar1.SelectionStart);
            }
        }

        private void buttonRoom19_Click(object sender, EventArgs e)
        {
            if (EmptyRoom[18])//如果是空房
            {
                textBox3.Text = buttonRoom19.Text;
            }
            else
            {
                showRoomData(buttonRoom19.Text, monthCalendar1.SelectionStart);
            }
        }

        private void buttonRoom20_Click(object sender, EventArgs e)
        {
            if (EmptyRoom[19])//如果是空房
            {
                textBox3.Text = buttonRoom20.Text;
            }
            else
            {
                showRoomData(buttonRoom20.Text, monthCalendar1.SelectionStart);
            }
        }

        private void buttonRoom21_Click(object sender, EventArgs e)
        {
            if (EmptyRoom[20])//如果是空房
            {
                textBox3.Text = buttonRoom21.Text;
            }
            else
            {
                showRoomData(buttonRoom21.Text, monthCalendar1.SelectionStart);
            }
        }

        private void buttonRoom22_Click(object sender, EventArgs e)
        {
            if (EmptyRoom[21])//如果是空房
            {
                textBox3.Text = buttonRoom22.Text;
            }
            else
            {
                showRoomData(buttonRoom22.Text, monthCalendar1.SelectionStart);
            }
        }

        private void buttonRoom23_Click(object sender, EventArgs e)
        {
            if (EmptyRoom[22])//如果是空房
            {
                textBox3.Text = buttonRoom23.Text;
            }
            else
            {
                showRoomData(buttonRoom23.Text, monthCalendar1.SelectionStart);
            }
        }

        private void buttonRoom24_Click(object sender, EventArgs e)
        {
            if (EmptyRoom[23])//如果是空房
            {
                textBox3.Text = buttonRoom24.Text;
            }
            else
            {
                showRoomData(buttonRoom24.Text, monthCalendar1.SelectionStart);
            }
        }

        private void buttonRoom25_Click(object sender, EventArgs e)
        {
            if (EmptyRoom[24])//如果是空房
            {
                textBox3.Text = buttonRoom25.Text;
            }
            else
            {
                showRoomData(buttonRoom25.Text, monthCalendar1.SelectionStart);
            }
        }

        private void buttonRoom26_Click(object sender, EventArgs e)
        {
            if (EmptyRoom[25])//如果是空房
            {
                textBox3.Text = buttonRoom26.Text;
            }
            else
            {
                showRoomData(buttonRoom26.Text, monthCalendar1.SelectionStart);
            }
        }

        private void buttonRoom27_Click(object sender, EventArgs e)
        {
            if (EmptyRoom[26])//如果是空房
            {
                textBox3.Text = buttonRoom27.Text;
            }
            else
            {
                showRoomData(buttonRoom27.Text, monthCalendar1.SelectionStart);
            }
        }

        private void buttonRoom28_Click(object sender, EventArgs e)
        {
            if (EmptyRoom[27])//如果是空房
            {
                textBox3.Text = buttonRoom28.Text;
            }
            else
            {
                showRoomData(buttonRoom28.Text, monthCalendar1.SelectionStart);
            }
        }

        private void buttonRoom29_Click(object sender, EventArgs e)
        {
            if (EmptyRoom[28])//如果是空房
            {
                textBox3.Text = buttonRoom29.Text;
            }
            else
            {
                showRoomData(buttonRoom29.Text, monthCalendar1.SelectionStart);
            }
        }

        private void buttonRoom30_Click(object sender, EventArgs e)
        {
            if (EmptyRoom[29])//如果是空房
            {
                textBox3.Text = buttonRoom30.Text;
            }
            else
            {
                showRoomData(buttonRoom30.Text, monthCalendar1.SelectionStart);
            }
        }



        /*測試
        private void buttonRoom30_Click(object sender, EventArgs e)
        {
            //buttonRoom30.BackColor = Color.PaleGreen;
            MessageBox.Show(buttonRoom30.BackColor.Equals(Color.PaleGreen).ToString());
        }
        */

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "410577031")
                label9.Text = "曾股長 歡迎您!!生意興隆"; //生意欣榮
            //groupBox1.Enabled = !groupBox1.Enabled;
            
            groupBox1.Enabled = true;
            monthCalendar1.SetDate(monthCalendar1.TodayDate);
            monthCalendar1.SetDate(monthCalendar1.TodayDate.AddDays(1));
            monthCalendar1.SetDate(monthCalendar1.TodayDate);

            monthCalendar2.SetDate(monthCalendar2.TodayDate);
            monthCalendar2.SetDate(monthCalendar2.TodayDate.AddDays(1));
            monthCalendar2.SetDate(monthCalendar2.TodayDate);
        }

        private void button32_Click(object sender, EventArgs e)
        {
            for (DateTime date = monthCalendar1.SelectionStart; DateTime.Compare(date, monthCalendar2.SelectionStart) <= 0; date = date.AddDays(1))
            {
                //string roomdateFILE = Path.Combine(Path.Combine(AllDataDirName, 房間), 日期 + ".csv");
                string roomDirName = Path.Combine(AllDataDirName, textBox3.Text+"\\");
                if (!Directory.Exists(roomDirName))
                    Directory.CreateDirectory(roomDirName);

                string roomdateFILE = Path.Combine(roomDirName, textBox3.Text+ date.ToString("yyyyMMdd") + ".csv");

                //如果檔案不存在，則建立；存在則覆蓋
                //該方法寫入字元陣列換行顯示
                string 是否抽菸 = checkBox1.Checked ? "抽菸" : "不抽菸";
                string[] lines = { monthCalendar1.SelectionStart.ToString("yyyy-MM-dd")
                                 , monthCalendar2.SelectionStart.ToString("yyyy-MM-dd")
                                 , textBox3.Text//房號
                                 , "是否抽菸"
                                 , textBox6.Text//客人名字
                                 , textBox7.Text//電話
                                 , textBox8.Text//備註
                                 };
                System.IO.File.WriteAllLines(roomdateFILE, lines, Encoding.UTF8);                
            }
            MessageBox.Show("訂房完成", "成功!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            monthCalendar1.Enabled = true;
            monthCalendar2.Enabled = true;
            label10.Visible = false;
            findEmptyRoom(monthCalendar1.SelectionStart);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            monthCalendar1.Enabled = true;
            monthCalendar2.Enabled = true;
            label10.Visible = false;
            findEmptyRoom(monthCalendar1.SelectionStart);
        }

        private void button34_Click(object sender, EventArgs e)
        {
            DateTime aa = new DateTime();
        }
    }
}
